package contactModule;

import java.io.IOException;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseClass;
import dataProviders.ContactDataProvider;
import pomPages.ContactCreatePomPage;
import pomPages.ContactPomPage;
import pomPages.HomePomPage;
import pomPages.LoginPomPage;
import utils.ExcelFileUtil;

public class CreateContactTest extends BaseClass {
	
	/**
	 * 
	 * @param data
	 * @throws IOException
	 * @throws InterruptedException
	 * 
	 * This TestNG class is used to create a new contact
	 */
	@Test(dataProvider = "contactDataProvider", 
			dataProviderClass = ContactDataProvider.class, 
			description = "Create Contact")
	public void createTest(Map<String, String> data) throws IOException, InterruptedException {
		
//		String orgName = data.get("ORG_NAME");
		String contactName = data.get("CONTACT_NAME");
		
//		Login to the application
		LoginPomPage lpp = new LoginPomPage(driver);
		lpp.Login();
		
		HomePomPage hpp = new HomePomPage(driver);
//		validate home page
		if(hpp.getHomePageHeading().equals("Home")) {
			System.out.println("Home page validated.");
		} else {
			System.out.println("Some error occurred");
			Assert.fail("Error Occured during Login");
		}
		
//		navigate to contact page
		hpp.clickOnContactTab();
		
//		identify the "Contact" tab and click on it
		ContactPomPage cpp = new ContactPomPage(driver);
		
//		create new contact
		cpp.clickCreateNewContact();
		
		ContactCreatePomPage ccpp = new ContactCreatePomPage(driver);
		
//		validate create Contact page
		if(ccpp.getCreateContactPageHeading().equals("Creating New Contact")) {
			System.out.println("Create Contact page validated.");
		} else {
			System.out.println("Some error occurred");
			Assert.fail("Error Occured");
		}
		
//		pass input to lastName TextField
		ccpp.getLastNameTf().sendKeys(contactName);
		
//		save the contact
		ccpp.clickSaveContact();
		
//		navigate back to the contact page
		hpp.clickOnContactTab();
		
		Thread.sleep(2000);
		
		String actualHeader = cpp.getContactHeader();

		try {
		    Assert.assertEquals(actualHeader, "Contacts");
		    ExcelFileUtil.writeData("Contact Data", 1, 4, "Pass");
		} catch (AssertionError e) {
		    ExcelFileUtil.writeData("Contact Data", 1, 4, "Fail");
		    throw e;
		}
		
//		ContactCreatedListPomPage cclp = new ContactCreatedListPomPage(driver); 
		
//		click on delete button
//		cclp.clickDelete();
//		
//		Thread.sleep(3000);
//		
////		handle popup
//		driver.switchTo().alert().accept();
		

	}

}
