package contactModule;

import java.io.IOException;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;
import dataProviders.ContactDataProvider;
import pomPages.ChildWindowPomPage;
import pomPages.ContactCreatePomPage;
import pomPages.ContactPomPage;
import pomPages.HomePomPage;
import pomPages.LoginPomPage;
import utils.ExcelFileUtil;

public class CreateContactWithOrganization extends BaseClass {
	
	/**
	 * 
	 * @param data
	 * @throws IOException
	 * @throws InterruptedException
	 * 
	 * This T
	 */
	@Test(dataProvider = "contactDataProvider", 
			dataProviderClass = ContactDataProvider.class, 
			description = "Create a Contact With Organization")
	public void CreateContactWithOrganizationTest(Map<String, String> data) throws IOException, InterruptedException {
		String orgName = data.get("ORG_NAME");
		String contactName = data.get("CONTACT_NAME");
		
//		Login to the application
		LoginPomPage lpp = new LoginPomPage(driver);
		lpp.Login();
		
		HomePomPage hpp = new HomePomPage(driver);
//		validate home page
		if(hpp.getHomePageHeading().equals("Home")) {
			System.out.println("Home page validated.");
		} else {
			System.out.println("Some error occurred");
			Assert.fail("Error Occured during Login");
		}
		
//		navigate to contact page
		hpp.clickOnContactTab();
		
//		identify the "Contact" tab and click on it
		ContactPomPage cpp = new ContactPomPage(driver);
		
//		create new contact
		cpp.clickCreateNewContact();
		
		ContactCreatePomPage ccpp = new ContactCreatePomPage(driver);
		
//		validate create Contact page
		if(ccpp.getCreateContactPageHeading().equals("Creating New Contact")) {
			System.out.println("Create Contact page validated.");
		} else {
			System.out.println("Some error occurred");
			Assert.fail("Error Occured");
		}
		
//		pass input to lastName TextField
		ccpp.getLastNameTf().sendKeys(contactName);
		
//		click on organization button
		ccpp.clickOnAddOrgBtn();
		
		ChildWindowPomPage cwpp = new ChildWindowPomPage(driver);
		String parentWindowId = cwpp.getPatentWindowId();
		String childWindowId = cwpp.getChildWindowId();
		
//		System.out.println(parentId);
//		System.out.println(childWinIds.get(1));
		
		driver.switchTo().window(childWindowId);

//		search a specific organization
		cwpp.searchOrgName(orgName);
		
		Thread.sleep(5000);
		
//		select Organization
		cwpp.clickOnSeletedOrg(orgName);
		
		Thread.sleep(5000);
		
//		switch back the driver controller to the parent window
		driver.switchTo().window(parentWindowId);
		
//		save the contact
		ccpp.clickSaveContact();
		
//		navigate back to the contact page
		hpp.clickOnContactTab();
		
		Thread.sleep(2000);
		
		String actualHeader = cpp.getContactHeader();
		
		try {
		    Assert.assertEquals(actualHeader, "Contacts");
		    ExcelFileUtil.writeData("Contact Data", 4, 5, "Pass");
		} catch (AssertionError e) {
		    ExcelFileUtil.writeData("Contact Data", 4, 5, "Fail");
		    throw e;
		}
	}

}
