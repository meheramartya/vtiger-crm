package organizationModule;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;
import dataProviders.OrgDataProvider;
import pomPages.HomePomPage;
import pomPages.LoginPomPage;
import pomPages.OrganizationCreatePomPage;
import pomPages.OrganizationCreatedListPomPage;
import pomPages.OrganizationPomPage;
import utils.ExcelFileUtil;
import utils.JavaUtility;

public class CreateOrgWithIndustryAndType extends BaseClass {
	
	/**
	 * 
	 * @param data
	 * @throws IOException
	 * @throws InterruptedException
	 * 
	 * This TestNG class is used to create an organization with industry and it's type
	 */
	@Test(dataProvider = "organizationDataProvider", 
			dataProviderClass = OrgDataProvider.class, 
			description = "Create Org With Industry and Type")
	public void CreateOrgWithIndustryAndTypeTest(Map<String, String> data) throws IOException, InterruptedException {
		
		JavaUtility ju = new JavaUtility();
		String orgName = data.get("ORG_NAME") + ju.fetchRandomInteger();		
		
//		Login to the application
		LoginPomPage lpp = new LoginPomPage(driver);
		lpp.Login();
		
		HomePomPage hpp = new HomePomPage(driver);
		
//		validate home page
		if(hpp.getHomePageHeading().equals("Home")) {
			System.out.println("Home page validated.");
		} else {
			System.out.println("Some error occurred");
			Assert.fail("Error Occured during Login");
		}
		
		
//		identify the "Organization" tab and click on it
		OrganizationPomPage opp = new OrganizationPomPage(driver);
		hpp.clickOnOrganizationTab();
		
//		create new organization
		opp.clickCreateNewOrganization();
		
		OrganizationCreatePomPage ocp = new OrganizationCreatePomPage(driver);
		
//		validate create Organization page
		if(ocp.getCreateOrgPageHeading().equals("Creating New Organization")) {
			System.out.println("Create Org page validated.");
		} else {
			System.out.println("Some error occurred");
			Assert.fail("Error Occured");
		}
		
//		pass input to Organization Name
		ocp.getOrgNameTextField().sendKeys(orgName);
		
//		select industry option
		WebElement industryDropdown = ocp.getIndustryDropdown();
		ocp.selectByValue(industryDropdown, data.get("INDUSTRY"));
		
//		select type option
		WebElement typeDropdown = ocp.getTypeDropdown();
		ocp.selectByValue(typeDropdown, data.get("TYPE"));
		
//		click on save button
		ocp.clickSave();
		
		OrganizationCreatedListPomPage ocl = new OrganizationCreatedListPomPage(driver);
		
//		validate Organization Info page
		if(ocl.getOrgInfoHeader().contains(orgName)) {
			System.out.println("Org Information page validated.");
		} else {
			System.out.println("Some error occurred");
			Assert.fail("Error Occured");
		}
		
//		click on organization tab
		hpp.clickOnOrganizationTab();
		
		Thread.sleep(2000);
		
		String actualHeader = opp.getOrgHeader();

		try {
		    Assert.assertEquals(actualHeader, "Organizations");
		    ExcelFileUtil.writeData("Organization Data", 4, 6, "Pass");
		} catch (AssertionError e) {
		    ExcelFileUtil.writeData("Organization Data", 4, 6, "Fail");
		    throw e;
		}
	}
}
