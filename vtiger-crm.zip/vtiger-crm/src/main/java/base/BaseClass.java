package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import utils.PropertyFileUtil;

public class BaseClass {
	
	protected WebDriver driver;
	PropertyFileUtil pfu = new PropertyFileUtil();
	
	@BeforeClass
	public void setUp() throws IOException {
		String browserName = pfu.getPropertyValue("browser");
		Long timeouts = Long.parseLong(pfu.getPropertyValue("timeouts"));
		
		if(browserName.equals("chrome")) {
			driver = new ChromeDriver();			
		} else if(browserName.equals("edge")) {
			driver = new EdgeDriver();
		} else {
			driver = new ChromeDriver();
		}
		
//		maximize the window
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeouts));
		
		String url = pfu.getPropertyValue("url");
		driver.get(url);
	}
	
	@AfterClass
	public void quitBrowser() {
		if(driver != null) {
			driver.quit();
		}
	}
	
	public WebDriver getDriver() {
	    return driver;
	}
	
}
