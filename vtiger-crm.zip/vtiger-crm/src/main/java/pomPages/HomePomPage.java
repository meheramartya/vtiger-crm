package pomPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.ActionsClassUtilities;

public class HomePomPage {
	
	public WebDriver driver;
	private ActionsClassUtilities action = null;
	
// Declare
	@FindBy(xpath = "//a[@class = 'hdrLink']")
	private WebElement homePageHeading;
	
	@FindBy(linkText = "Organizations")
	private WebElement organizationTab;
	
	@FindBy(linkText = "Contacts")
	private WebElement contactsTab;
	
	
//	initialize
	public HomePomPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		action = new ActionsClassUtilities(driver);
	}
	
//	utilize
	public String getHomePageHeading() {
		return homePageHeading.getText();
	}
	
	public WebElement getOrganizationTab() {
		return organizationTab;
	}
	
	public WebElement getContactTab() {
		return contactsTab;
	}
	
//	action
	public void clickOnOrganizationTab() {
		action.performMouseClickAction(getOrganizationTab());
	}
	
	public void clickOnContactTab() {
		action.performMouseClickAction(getContactTab());
	}

}
