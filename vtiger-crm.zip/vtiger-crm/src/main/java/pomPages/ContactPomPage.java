package pomPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.ActionsClassUtilities;
import utils.SelectClassUtilities;

public class ContactPomPage {
	
	public WebDriver driver;
	private ActionsClassUtilities action = null;
	
//	Declare
	@FindBy(xpath = "//a//img[@title = 'Create Contact...']/..")
	private WebElement createContactBtn;
	
	
	@FindBy(xpath = "//a[@class=\"hdrLink\" and text() = 'Contacts']")
	private WebElement contactPageHeader;
		
//	initialize
	public ContactPomPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		action = new ActionsClassUtilities(driver);
	}
	
//	utilize
	public WebElement getCreateContactBtn() {
		return createContactBtn;
	}	
	
	public String getContactHeader() {
		return contactPageHeader.getText();
	}
	
//	action
	public void clickCreateNewContact() {
		action.performMouseClickAction(getCreateContactBtn());
	}
}
