package pomPages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.ActionsClassUtilities;

public class ChildWindowPomPage {

	public WebDriver driver;
	private ActionsClassUtilities action = null;
	
	final String orgName = "Nebula";
	
//	Declare
	@FindBy(id = "search_txt")
	private WebElement searchBox;
	
	@FindBy(xpath = "//input[@name = 'search']")
	private WebElement searchNowBtn;
	
	
//	Initialize
	public ChildWindowPomPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		action = new ActionsClassUtilities(driver);
	}
	
	
//	Utility	
	
	public String getPatentWindowId() {
		return driver.getWindowHandle();
	}
	
	public String getChildWindowId(){
		return new ArrayList<>(driver.getWindowHandles()).get(1);
	}
	
	public WebElement getSelectedOrg(String orgName) {
	    return driver.findElement(By.xpath("//a[text()='" + orgName + "']"));
	}
	
	public WebElement getSearchBox() {
		return searchBox;
	}
	
	public WebElement getSearchNowBtn() {
		return searchNowBtn;
	}
	
	public void searchOrgName(String orgName) {
		getSearchBox().sendKeys(orgName);
		action.performMouseClickAction(getSearchNowBtn());
	}
	
	
//	action
	
	public void clickOnSeletedOrg(String orgName) {
		action.performMouseClickAction(getSelectedOrg(orgName));
	}
}
