package listeners;

import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;
import base.BaseClass;
import utils.ScreenShotUtil;

public class TestListener implements ITestListener{
	
	@Override
	public void onTestFailure(ITestResult result) {
		
		// this will give current test scripts reference
		Object testClass = result.getInstance();
	    WebDriver driver = ((BaseClass) testClass).getDriver();
		
		String testName = result.getName();
		System.out.println("Test Execution Failed ---> Take ScreenShot" + driver);
		ScreenShotUtil.captureScreenShot(driver, testName);
		System.out.println("Screenshot has been taken....check in screenshot folder");
	}
	

}
